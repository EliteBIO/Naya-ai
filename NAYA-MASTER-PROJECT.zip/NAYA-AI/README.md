# NAYA AI — Phase 2 (Gemini chat)

This project continues the Phase 1 Android app. Package: `com.naya.ai`; minimum Android: 12 (API 31).

## What Phase 2 adds
- Gemini-backed chat through a server-side HTTPS proxy (default model: `gemini-3.8-flash`).
- Streaming text responses.
- Local persistent chat history using Android SQLite.
- Backend URL setup inside the Chat screen.
- Hindi, English and Hinglish assistant instructions.
- Clear-chat and connection status.

Photo/video generation, female voice, animated facial rig, and actual device automation are NOT implemented by this phase.

## Required setup
1. Deploy the Cloudflare Worker in `backend/` (see `backend/README.md`).
2. Set `GEMINI_API_KEY` as a Worker secret, never in Android source or GitHub.
3. Check the current Google AI Studio account eligibility, Gemini API model availability, free-tier quota, terms and data handling. Free quota is not guaranteed and may change.
4. Build/install the updated APK. Version code is incremented to 2 so it can update the Phase 1 installation.
5. Open NAYA → Chat → Setup and paste the Worker HTTPS base URL.
6. Send `Hello NAYA`.

## Build APK from a phone with GitHub Actions
1. Upload the extracted project files to the repository root (or upload this ZIP and keep the workflow file at `.github/workflows/build-apk.yml`).
2. Commit to `main` or `master`.
3. Open Actions → Build NAYA AI debug APK.
4. Download the `NAYA-AI-debug-apk` artifact and extract `app-debug.apk`.

The workflow uses Gradle 8.10.2 and Java 17.

## Security
- Never paste a Gemini key into the app, chat, source code, or a public repository. Have a parent/guardian help with provider account setup if required by the provider's age and account rules; do not bypass age requirements.
- The Worker starter has basic input validation but does not yet provide strong user authentication or durable per-user rate limits. Do not expose a public production service without adding those controls.
- Free-tier API data handling may differ from paid-tier handling; avoid confidential information.

## Honest test status
The project package/application ID remains `com.naya.ai` to support updating the installed Phase 1 app.

This ZIP has been updated by source inspection. It has NOT been compiled or run in an Android emulator/device in this environment. GitHub Actions is the first full Gradle build. Fix any CI errors before treating the APK as verified.
