package com.naya.ai.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSettings(
    val displayName: String = "",
    val language: String = "hinglish", // english | hindi | hinglish
    val speechSpeed: Float = 1f,
    val speechPitch: Float = 1f,
)

/** Local-only settings store (SharedPreferences). No network, no secrets. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("naya_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun load() = UserSettings(
        displayName = prefs.getString("name", "") ?: "",
        language = prefs.getString("lang", "hinglish") ?: "hinglish",
        speechSpeed = prefs.getFloat("speed", 1f),
        speechPitch = prefs.getFloat("pitch", 1f),
    )

    fun update(change: (UserSettings) -> UserSettings) {
        val s = change(_settings.value)
        _settings.value = s
        prefs.edit()
            .putString("name", s.displayName)
            .putString("lang", s.language)
            .putFloat("speed", s.speechSpeed)
            .putFloat("pitch", s.speechPitch)
            .apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
        _settings.value = UserSettings()
    }
}
