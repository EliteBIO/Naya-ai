package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun ToolsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val battery = remember {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "Unavailable"
    }
    val now = remember { LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) }

    ScreenColumn {
        ScreenHeader("Tools", "Local utilities that work offline", onBack)
        SectionTitle("This device")
        GlassCard(Modifier.fillMaxWidth()) {
            InfoRow("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
            InfoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            InfoRow("Battery", battery)
            InfoRow("Date and time", now)
        }
        FeatureList(
            listOf(
                Feature("Device information", "Working", working = true),
                Feature("Calculator", "Phase 7"),
                Feature("Notes", "Phase 7"),
                Feature("Reminders and notifications", "Phase 7"),
                Feature("Open apps", "Phase 7"),
                Feature("File and gallery tools", "Phase 7"),
            ),
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = NayaColors.TextDim, fontSize = 13.sp)
        Text(value, color = NayaColors.TextPrimary, fontSize = 13.sp)
    }
}
