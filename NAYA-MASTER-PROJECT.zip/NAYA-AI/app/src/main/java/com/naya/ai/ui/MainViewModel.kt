package com.naya.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.naya.ai.avatar.AvatarController
import com.naya.ai.data.SettingsRepository

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = SettingsRepository(app)
    val settings = repo.settings
    val avatar = AvatarController()
}
