package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import com.naya.ai.ui.ChatMessage
import com.naya.ai.ui.ChatViewModel

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val status by vm.status.collectAsState()
    val endpoint by vm.endpoint.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var endpointDraft by remember(endpoint) { mutableStateOf(endpoint) }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.text) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                ScreenHeader("AI Chat", "Gemini-powered personal assistant")
                Text(status, color = if (endpoint.startsWith("https://")) NayaColors.Blue else NayaColors.Warn, fontSize = 11.sp)
            }
            TextButton(onClick = { showSettings = true }) { Text("⚙ Setup") }
            TextButton(onClick = { vm.clearChat() }) { Text("Clear") }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages, key = { it.id }) { Bubble(it) }
            if (busy) item { Text("NAYA is thinking…", color = NayaColors.Blue, fontSize = 12.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message NAYA…") }, colors = nayaFieldColors(), shape = RoundedCornerShape(24.dp), maxLines = 4, enabled = !busy)
            Spacer(Modifier.width(8.dp))
            NeonButton(if (busy) "Wait" else "Send", enabled = input.isNotBlank() && !busy) {
                vm.send(input.trim()); input = ""
            }
        }
    }
    if (showSettings) Dialog(onDismissRequest = { showSettings = false }) {
        Surface(shape = RoundedCornerShape(22.dp), color = NayaColors.Navy2) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Connect NAYA Backend", color = NayaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Paste your deployed HTTPS backend URL. Never paste your Gemini API key here.", color = NayaColors.TextDim, fontSize = 12.sp)
                OutlinedTextField(value = endpointDraft, onValueChange = { endpointDraft = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://your-worker.workers.dev") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { showSettings = false }) { Text("Cancel") }
                    TextButton(onClick = { vm.setEndpoint(endpointDraft); showSettings = false }) { Text("Save") }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val shape = RoundedCornerShape(18.dp)
    val tint = when { m.isSystem -> NayaColors.Warn; m.fromUser -> NayaColors.Blue; else -> NayaColors.Purple }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Text(m.text.ifEmpty { "…" }, color = NayaColors.TextPrimary, fontSize = 14.sp,
            modifier = Modifier.widthIn(max = 300.dp).background(tint.copy(alpha = 0.18f), shape).border(1.dp, tint.copy(alpha = 0.45f), shape).padding(12.dp))
    }
}
