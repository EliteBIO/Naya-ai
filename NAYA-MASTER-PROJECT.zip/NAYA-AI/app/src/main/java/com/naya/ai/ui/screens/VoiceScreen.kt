package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.avatar.Expression
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.ui.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceScreen(vm: MainViewModel, onExit: () -> Unit) {
    val state by vm.avatar.state.collectAsState()

    ScreenColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NAYA Avatar", color = NayaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Voice assistant mode", color = NayaColors.TextDim, fontSize = 12.sp)
            }
            IconTextButton("✕", onExit)
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            NayaAvatarView(state, 300.dp)
        }
        Text(
            state.expression.label,
            Modifier.fillMaxWidth(),
            color = state.expression.aura, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        )
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            StatusBadge("Preview only: facial animation arrives in Phase 4")
        }

        SectionTitle("Expression preview")
        Text("Tap an expression to see the avatar state controller switch (aura color + label).", color = NayaColors.TextDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Expression.values().forEach { e ->
                FilterChip(
                    selected = state.expression == e,
                    onClick = { vm.avatar.setExpression(e) },
                    label = { Text(e.label) },
                    colors = nayaChipColors(),
                )
            }
        }

        SectionTitle("Voice controls")
        FeatureList(
            listOf(
                Feature("Push-to-talk microphone", "Phase 3"),
                Feature("Speech recognition (Hindi / English / Hinglish)", "Phase 3"),
                Feature("Female text-to-speech voice", "Phase 3"),
                Feature("Mute and stop speaking", "Phase 3"),
                Feature("Live response text", "Phase 2"),
                Feature("Lip-sync and facial animation", "Phase 4"),
                Feature("Expression preview and exit", "Working", working = true),
            ),
        )
        Spacer(Modifier.height(8.dp))
    }
}
