package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.avatar.AvatarState
import com.naya.ai.ui.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onProfile: () -> Unit) {
    val s by vm.settings.collectAsState()
    val sliderColors = SliderDefaults.colors(thumbColor = NayaColors.Blue, activeTrackColor = NayaColors.Blue)

    ScreenColumn {
        ScreenHeader("Settings", null, onBack)

        GlassCard(Modifier.fillMaxWidth(), onClick = onProfile) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NayaAvatarView(AvatarState(), 64.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (s.displayName.isBlank()) "Set up your profile" else s.displayName,
                        color = NayaColors.TextPrimary, fontWeight = FontWeight.SemiBold,
                    )
                    Text("Tap to edit profile", color = NayaColors.TextDim, fontSize = 12.sp)
                }
                Text("›", color = NayaColors.TextDim, fontSize = 24.sp)
            }
        }

        SectionTitle("Language")
        Text("Saved now. Used by AI and voice from Phase 2–3.", color = NayaColors.TextDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("english" to "English", "hindi" to "हिन्दी", "hinglish" to "Hinglish").forEach { (key, label) ->
                FilterChip(
                    selected = s.language == key,
                    onClick = { vm.repo.update { it.copy(language = key) } },
                    label = { Text(label) },
                    colors = nayaChipColors(),
                )
            }
        }

        SectionTitle("Voice")
        Text("Speed ${"%.1f".format(s.speechSpeed)}x", color = NayaColors.TextPrimary, fontSize = 13.sp)
        Slider(
            value = s.speechSpeed,
            onValueChange = { v -> vm.repo.update { it.copy(speechSpeed = v) } },
            valueRange = 0.5f..2f,
            colors = sliderColors,
        )
        Text("Pitch ${"%.1f".format(s.speechPitch)}", color = NayaColors.TextPrimary, fontSize = 13.sp)
        Slider(
            value = s.speechPitch,
            onValueChange = { v -> vm.repo.update { it.copy(speechPitch = v) } },
            valueRange = 0.5f..2f,
            colors = sliderColors,
        )
        StatusBadge("Applied when voice arrives in Phase 3")

        SectionTitle("Coming in later phases")
        FeatureList(
            listOf(
                Feature("AI provider and model selection", "Phase 2"),
                Feature("Secure API key storage", "Phase 2"),
                Feature("Voice selection", "Phase 3"),
                Feature("Notifications", "Phase 7"),
                Feature("Memory controls", "Phase 9"),
                Feature("Theme options", "Phase 10"),
            ),
        )

        SectionTitle("Privacy")
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "Phase 1 stores only your name, language and voice sliders on this device. " +
                    "It makes no network requests, uses no microphone or camera, and sends no analytics.",
                color = NayaColors.TextDim, fontSize = 13.sp,
            )
        }
        NeonButton("Reset all settings", Modifier.fillMaxWidth()) { vm.repo.reset() }

        SectionTitle("About")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("NAYA AI", color = NayaColors.TextPrimary, fontWeight = FontWeight.Bold)
            Text("Your personal AI", color = NayaColors.TextDim, fontSize = 12.sp)
            Text("Version 0.1.0 (Phase 1)", color = NayaColors.TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
