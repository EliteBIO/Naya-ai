package com.naya.ai.avatar

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.naya.ai.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** The 12 expressions required by the NAYA spec. Phase 4 maps each to a rig pose. */
enum class Expression(val label: String, val aura: Color) {
    Neutral("Neutral", Color(0xFF3DA9FF)),
    Happy("Happy", Color(0xFF4DD0FF)),
    Smiling("Smiling", Color(0xFF6FA8FF)),
    Laughing("Laughing", Color(0xFFFFC857)),
    Thinking("Thinking", Color(0xFF9B5CFF)),
    Confused("Confused", Color(0xFFB08CFF)),
    Surprised("Surprised", Color(0xFFFF6FD8)),
    Excited("Excited", Color(0xFFFF7A59)),
    Concerned("Concerned", Color(0xFF5C7CFF)),
    Explaining("Explaining", Color(0xFF3DFFD0)),
    Listening("Listening", Color(0xFF4DFFB0)),
    Speaking("Speaking", Color(0xFF3DA9FF)),
}

/** What the avatar should look like right now. mouthOpen (0..1) is reserved for Phase 4 lip-sync. */
data class AvatarState(
    val expression: Expression = Expression.Neutral,
    val mouthOpen: Float = 0f,
)

/** Single source of truth for the avatar. UI observes it; AI/voice layers will drive it. */
class AvatarController {
    private val _state = MutableStateFlow(AvatarState())
    val state: StateFlow<AvatarState> = _state.asStateFlow()

    fun setExpression(e: Expression) = _state.update { it.copy(expression = e) }
    fun setMouthOpen(v: Float) = _state.update { it.copy(mouthOpen = v.coerceIn(0f, 1f)) }
}

/** Conversation events -> expression. Phase 4 wires this to real AI/voice state. */
enum class ConversationEvent { Idle, UserGreeted, UserSpeaking, ThinkingHard, Explaining, AiSpeaking, TaskDone, Discovery, Unclear, BadNews }

object ExpressionResolver {
    fun resolve(e: ConversationEvent): Expression = when (e) {
        ConversationEvent.Idle -> Expression.Neutral
        ConversationEvent.UserGreeted -> Expression.Smiling
        ConversationEvent.UserSpeaking -> Expression.Listening
        ConversationEvent.ThinkingHard -> Expression.Thinking
        ConversationEvent.Explaining -> Expression.Explaining
        ConversationEvent.AiSpeaking -> Expression.Speaking
        ConversationEvent.TaskDone -> Expression.Excited
        ConversationEvent.Discovery -> Expression.Surprised
        ConversationEvent.Unclear -> Expression.Confused
        ConversationEvent.BadNews -> Expression.Concerned
    }
}

/** Swap point: Phase 4 replaces StaticAvatarRenderer with a Rive/Live2D renderer. */
interface AvatarRenderer {
    @Composable
    fun Render(state: AvatarState, size: Dp, modifier: Modifier)
}

object AvatarRenderers {
    var current: AvatarRenderer = StaticAvatarRenderer
}

/** Phase 1: your exact character image + an expression-colored aura. No facial animation yet. */
object StaticAvatarRenderer : AvatarRenderer {
    @Composable
    override fun Render(state: AvatarState, size: Dp, modifier: Modifier) {
        val transition = rememberInfiniteTransition(label = "aura")
        val pulse by transition.animateFloat(
            initialValue = 0.88f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulse",
        )
        val aura by animateColorAsState(state.expression.aura, tween(500), label = "auraColor")
        Box(modifier.size(size), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(size)
                    .scale(pulse)
                    .background(Brush.radialGradient(listOf(aura.copy(alpha = 0.55f), Color.Transparent)), CircleShape),
            )
            Image(
                painter = painterResource(R.drawable.naya_avatar),
                contentDescription = "NAYA",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size * 0.82f)
                    .clip(CircleShape)
                    .border(2.dp, aura, CircleShape),
            )
        }
    }
}

@Composable
fun NayaAvatarView(state: AvatarState, size: Dp, modifier: Modifier = Modifier) {
    AvatarRenderers.current.Render(state, size, modifier)
}
