package com.naya.ai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Small local conversation store. No chat content leaves the device except messages sent to the chosen AI backend. */
class ChatStore(context: Context) : SQLiteOpenHelper(context, "naya_chat.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }
    fun add(role: String, body: String) {
        writableDatabase.insert("messages", null, ContentValues().apply {
            put("role", role); put("body", body); put("created_at", System.currentTimeMillis())
        })
    }
    fun all(): List<StoredMessage> {
        val out = mutableListOf<StoredMessage>()
        readableDatabase.rawQuery("SELECT id, role, body FROM messages ORDER BY id", null).use { c ->
            while (c.moveToNext()) out += StoredMessage(c.getLong(0), c.getString(1), c.getString(2))
        }
        return out
    }
    fun clear() { writableDatabase.delete("messages", null, null) }
}
data class StoredMessage(val id: Long, val role: String, val body: String)
