package com.naya.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.naya.ai.core.BackendSettings
import com.naya.ai.core.ChatTurn
import com.naya.ai.core.GeminiBackendClient
import com.naya.ai.data.ChatStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String, val isSystem: Boolean = false)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ChatStore(app)
    private val settings = BackendSettings(app)
    private var nextId = 1L
    private val _messages = MutableStateFlow<List<ChatMessage>>(restore())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _status = MutableStateFlow(if (settings.endpoint.isBlank()) "Backend not configured" else "Backend configured")
    val status: StateFlow<String> = _status.asStateFlow()
    private val _endpoint = MutableStateFlow(settings.endpoint)
    val endpoint: StateFlow<String> = _endpoint.asStateFlow()

    private fun restore(): List<ChatMessage> {
        val saved = store.all().map { ChatMessage(it.id, it.role == "user", it.body) }
        nextId = (saved.maxOfOrNull { it.id } ?: 0L) + 1L
        return saved.ifEmpty { listOf(ChatMessage(0, false, "Hi! I'm NAYA. Connect your secure Gemini backend to start chatting." , true)) }
    }
    fun setEndpoint(value: String) {
        settings.endpoint = value
        _endpoint.value = settings.endpoint
        _status.value = if (settings.endpoint.startsWith("https://")) "Backend configured" else "Backend not configured"
    }
    fun clearChat() { store.clear(); _messages.value = emptyList() }
    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || _busy.value) return
        val user = ChatMessage(nextId++, true, prompt)
        store.add("user", prompt)
        _messages.update { it.filterNot { m -> m.isSystem } + user }
        if (_endpoint.value.isBlank()) {
            _messages.update { it + ChatMessage(nextId++, false, "Please configure your HTTPS backend URL using the settings button. No API key is needed in the app.", true) }
            return
        }
        viewModelScope.launch {
            _busy.value = true
            val answerId = nextId++
            _messages.update { it + ChatMessage(answerId, false, "") }
            try {
                val history = _messages.value.filter { !it.isSystem && it.text.isNotBlank() && it.id != answerId }
                    .map { ChatTurn(if (it.fromUser) "user" else "assistant", it.text) }
                val reply = GeminiBackendClient(_endpoint.value).streamReply(history) { chunk ->
                    _messages.update { list -> list.map { if (it.id == answerId) it.copy(text = it.text + chunk) else it } }
                }
                if (reply.isNotBlank()) store.add("assistant", reply)
                else _messages.update { list -> list.map { if (it.id == answerId) it.copy(text = "NAYA received an empty response. Please try again.", isSystem = true) else it } }
            } catch (e: Exception) {
                val msg = e.message?.take(220) ?: "Unable to contact NAYA backend."
                _messages.update { list -> list.map { if (it.id == answerId) it.copy(text = "Connection error: $msg", isSystem = true) else it } }
            } finally { _busy.value = false }
        }
    }
}
