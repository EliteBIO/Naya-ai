package com.naya.ai.core

import android.content.Context

class BackendSettings(context: Context) {
    private val prefs = context.getSharedPreferences("naya_backend", Context.MODE_PRIVATE)
    var endpoint: String
        get() = prefs.getString("endpoint", "") ?: ""
        set(value) { prefs.edit().putString("endpoint", value.trim().trimEnd('/')).apply() }
}
