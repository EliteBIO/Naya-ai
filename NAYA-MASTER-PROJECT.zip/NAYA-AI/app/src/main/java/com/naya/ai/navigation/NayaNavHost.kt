package com.naya.ai.navigation

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.naya.ai.ui.ChatViewModel
import com.naya.ai.ui.MainViewModel
import com.naya.ai.ui.screens.*
import com.naya.ai.ui.theme.NayaColors
import com.naya.ai.ui.theme.nayaBackground

object Routes {
    const val Home = "home"
    const val Chat = "chat"
    const val Voice = "voice"
    const val Photo = "photo"
    const val Video = "video"
    const val Tools = "tools"
    const val Business = "business"
    const val Settings = "settings"
    const val Profile = "profile"
}

private data class NavItem(val route: String, val label: String, val glyph: String)

private val bottomItems = listOf(
    NavItem(Routes.Home, "Home", "🏠"),
    NavItem(Routes.Chat, "Chat", "💬"),
    NavItem(Routes.Voice, "Avatar", "🎙"),
    NavItem(Routes.Photo, "Photo", "🖼"),
    NavItem(Routes.Video, "Video", "🎬"),
)

private fun NavController.go(route: String) {
    if (bottomItems.any { it.route == route }) {
        navigate(route) {
            popUpTo(graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    } else {
        navigate(route) { launchSingleTop = true }
    }
}

@Composable
fun NayaNavHost() {
    val nav = rememberNavController()
    val mainVm: MainViewModel = viewModel()
    val chatVm: ChatViewModel = viewModel()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val go: (String) -> Unit = { nav.go(it) }
    val back: () -> Unit = { nav.popBackStack() }

    Box(Modifier.fillMaxSize().nayaBackground()) {
        Scaffold(
            modifier = Modifier.imePadding(),
            containerColor = Color.Transparent,
            bottomBar = { if (route != Routes.Voice) NayaBottomBar(route, go) },
        ) { pad ->
            NavHost(nav, startDestination = Routes.Home, modifier = Modifier.padding(pad)) {
                composable(Routes.Home) { HomeScreen(mainVm, go) }
                composable(Routes.Chat) { ChatScreen(chatVm) }
                composable(Routes.Voice) { VoiceScreen(mainVm, onExit = back) }
                composable(Routes.Photo) { PhotoStudioScreen() }
                composable(Routes.Video) { VideoStudioScreen() }
                composable(Routes.Tools) { ToolsScreen(onBack = back) }
                composable(Routes.Business) { BusinessScreen(onBack = back) }
                composable(Routes.Settings) { SettingsScreen(mainVm, onBack = back, onProfile = { go(Routes.Profile) }) }
                composable(Routes.Profile) { ProfileScreen(mainVm, onBack = back) }
            }
        }
    }
}

@Composable
private fun NayaBottomBar(route: String?, onNav: (String) -> Unit) {
    NavigationBar(containerColor = NayaColors.Navy.copy(alpha = 0.92f)) {
        bottomItems.forEach { item ->
            NavigationBarItem(
                selected = route == item.route,
                onClick = { onNav(item.route) },
                icon = { Text(item.glyph, fontSize = 20.sp) },
                label = { Text(item.label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedTextColor = NayaColors.Blue,
                    unselectedTextColor = NayaColors.TextDim,
                    indicatorColor = NayaColors.Navy2,
                ),
            )
        }
    }
}
