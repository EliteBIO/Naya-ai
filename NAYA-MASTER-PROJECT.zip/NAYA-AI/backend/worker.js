const SYSTEM = `You are NAYA, a friendly, intelligent female personal AI assistant. Reply naturally in the language used by the user: Hindi, English, or Hinglish. Be accurate, helpful, respectful and concise. Never claim to have performed an action you did not perform. You do not have direct access to the user's Android device; only describe actions or use tools that the app explicitly implements.`;

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (url.pathname === "/health" && request.method === "GET")
      return Response.json({ ok: true, service: "NAYA backend" }, { headers: cors });
    if (url.pathname !== "/chat" || request.method !== "POST")
      return Response.json({ error: "Not found" }, { status: 404, headers: cors });
    if (!env.GEMINI_API_KEY)
      return Response.json({ error: "Backend owner has not configured GEMINI_API_KEY." }, { status: 503, headers: cors });
    let body;
    try { body = await request.json(); } catch { return Response.json({ error: "Invalid JSON." }, { status: 400, headers: cors }); }
    if (!Array.isArray(body.history) || body.history.length === 0 || body.history.length > 40)
      return Response.json({ error: "Send between 1 and 40 conversation turns." }, { status: 400, headers: cors });
    const contents = [];
    for (const item of body.history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string" || !item.text.trim() || item.text.length > 8000)
        return Response.json({ error: "Invalid or oversized conversation turn." }, { status: 400, headers: cors });
      contents.push({ role: item.role, parts: [{ text: item.text }] });
    }
    const model = env.GEMINI_MODEL || "gemini-3.8-flash";
    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${env.GEMINI_API_KEY}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents, generationConfig: { maxOutputTokens: 1200, temperature: 0.7 } }),
    });
    if (!upstream.ok) {
      const details = await upstream.text();
      return Response.json({ error: `Gemini API error (${upstream.status}): ${details.slice(0, 500)}` }, { status: upstream.status, headers: cors });
    }
    const headers = new Headers(cors);
    headers.set("Content-Type", "text/event-stream; charset=utf-8");
    headers.set("Cache-Control", "no-cache, no-transform");
    return new Response(upstream.body, { status: 200, headers });
  }
};
