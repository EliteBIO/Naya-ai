# NAYA Gemini backend (Cloudflare Worker)

This proxy keeps the Gemini API key on the server, not inside the Android APK.

## Deploy from a trusted account holder's Cloudflare account
1. Create a Worker and deploy `worker.js` (or use Wrangler from a development computer).
2. Set the Worker secret `GEMINI_API_KEY` in Worker Settings → Variables and Secrets. Never put it in this repository.
3. Optional: set `GEMINI_MODEL` to a model currently enabled for your API key. Default: `gemini-3.8-flash`.
4. Deploy and open `https://YOUR-WORKER.workers.dev/health`. Expect `{"ok":true,...}`.
5. In NAYA → Chat → Setup, paste the Worker base URL (without `/chat`).

## Wrangler CLI alternative
From this directory: `npx wrangler secret put GEMINI_API_KEY`, then `npx wrangler deploy`.

## Notes
- The Worker validates message count and size and streams Gemini SSE responses.
- This starter does not include strong per-user authentication or durable rate limiting. Before public distribution, add authentication, abuse controls, and per-user quotas.
- Free-tier eligibility, model availability, quotas, and data handling are controlled by Google and can change. Check current Gemini API terms and pricing.
- Do not send confidential personal or customer information to a free-tier API.
