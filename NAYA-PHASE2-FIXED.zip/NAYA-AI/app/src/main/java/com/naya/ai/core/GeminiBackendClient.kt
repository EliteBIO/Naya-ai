package com.naya.ai.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class GeminiBackendClient(private val endpoint: String) {
    suspend fun streamReply(history: List<ChatTurn>, onChunk: (String) -> Unit): String = withContext(Dispatchers.IO) {
        require(endpoint.startsWith("https://")) { "Set your secure HTTPS backend URL in NAYA Chat settings first." }
        val conn = (URL("$endpoint/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "text/event-stream")
        }
        try {
            val turns = JSONArray()
            history.forEach { turns.put(JSONObject().put("role", if (it.role == "assistant") "model" else "user").put("text", it.text)) }
            val payload = JSONObject().put("history", turns).toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) {
                val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IllegalStateException("Backend error ${conn.responseCode}: ${error.take(300)}")
            }
            val result = StringBuilder()
            BufferedReader(InputStreamReader(conn.inputStream)).useLines { lines ->
                lines.forEach { line ->
                    if (line.startsWith("data:")) {
                        val raw = line.removePrefix("data:").trim()
                        if (raw.isNotEmpty() && raw != "[DONE]") {
                            val json = JSONObject(raw)
                            val text = json.optJSONArray("candidates")?.optJSONObject(0)
                                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()
                            if (text.isNotEmpty()) { result.append(text); onChunk(text) }
                            val error = json.optJSONObject("error")
                            if (error != null) throw IllegalStateException(error.optString("message", "AI provider error"))
                        }
                    }
                }
            }
            result.toString()
        } finally { conn.disconnect() }
    }
}
data class ChatTurn(val role: String, val text: String)
