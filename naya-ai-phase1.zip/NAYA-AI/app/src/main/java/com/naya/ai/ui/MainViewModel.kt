package com.naya.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.naya.ai.avatar.AvatarController
import com.naya.ai.data.SecureKeyStore
import com.naya.ai.data.SettingsRepository

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = SettingsRepository.get(app)
    val settings = repo.settings
    val secure = SecureKeyStore(app)
    val avatar = AvatarController()
}
