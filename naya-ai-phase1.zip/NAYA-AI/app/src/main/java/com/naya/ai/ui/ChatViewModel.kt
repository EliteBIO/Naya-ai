package com.naya.ai.ui

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String, val isSystem: Boolean = false)

/** Phase 1: in-memory only. Phase 2 adds Room storage and a real AI provider. */
class ChatViewModel : ViewModel() {
    private var nextId = 1L
    private val _messages = MutableStateFlow(
        listOf(
            ChatMessage(
                0, false,
                "Hi, I'm NAYA. My AI brain isn't connected yet (Phase 2). You can type here, but I can't reply until a provider is set up.",
                isSystem = true,
            ),
        ),
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    fun send(text: String) {
        _messages.update {
            it + ChatMessage(nextId++, true, text) +
                ChatMessage(nextId++, false, "No AI provider connected yet. Replies arrive in Phase 2.", isSystem = true)
        }
    }
}
