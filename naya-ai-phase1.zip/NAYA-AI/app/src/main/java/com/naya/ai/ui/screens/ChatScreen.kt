package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.ui.ChatMessage
import com.naya.ai.ui.ChatViewModel

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val messages by vm.messages.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { listState.animateScrollToItem(messages.lastIndex) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader("AI Chat", "Session only — not saved yet")
        StatusBadge("AI provider: awaiting Phase 2")
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages, key = { it.id }) { Bubble(it) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message NAYA…") },
                colors = nayaFieldColors(),
                shape = RoundedCornerShape(24.dp),
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            NeonButton("Send", enabled = input.isNotBlank()) {
                vm.send(input.trim())
                input = ""
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val shape = RoundedCornerShape(18.dp)
    val tint = when {
        m.isSystem -> NayaColors.Warn
        m.fromUser -> NayaColors.Blue
        else -> NayaColors.Purple
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Text(
            m.text,
            color = NayaColors.TextPrimary,
            fontSize = 14.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(tint.copy(alpha = 0.18f), shape)
                .border(1.dp, tint.copy(alpha = 0.45f), shape)
                .padding(12.dp),
        )
    }
}
