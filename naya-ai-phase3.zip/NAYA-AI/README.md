# NAYA AI — Phase 3

Kotlin + Jetpack Compose + Material 3. Min Android 12 (API 31). Single module, packages: core, data, avatar, navigation, ui.

## Status (honest)
**Not compiled or run by the author yet.** The first GitHub Actions build is the first real compile. If it fails, open the failed run, copy the error and send it back for a fix.

| Feature | Status |
|---|---|
| Dashboard, 5-tab navigation, Tools/Business/Settings/Profile routes | Working (UI) |
| Your character as avatar + app icon (static image, expression-colored aura) | Working |
| 12-expression state controller (tap to preview on Avatar screen) | Working (no facial animation) |
| Online/offline indicator, device info, battery, date | Working |
| Profile name, language, voice sliders (saved locally) | Working (values used from Phase 3-3) |
| Gallery image picker + preview, video picker + info + first frame | Working |
| Chat input | Works locally; no AI replies (Phase 3) |
| AI brain, voice, rigged avatar/lip-sync, image & video generation, tools, business, memory | Awaiting later phases, marked in-app |

## Build the APK from your phone (no PC)
1. Create a free account at github.com and a new repository (e.g. `naya-ai`).
2. In the repo: **Add file > Upload files**, choose `naya-ai-phase2.zip`, tap **Commit changes**.
3. **Add file > Create new file**. In the name box type exactly `.github/workflows/build-apk.yml` (typing `/` creates folders). Paste the contents of `build-apk.yml`. Tap **Commit changes**.
4. Open the **Actions** tab > **Build NAYA AI debug APK**. It starts by itself after step 3; otherwise tap **Run workflow**. Takes about 5-10 min.
5. Open the finished run, scroll to **Artifacts**, download `NAYA-AI-debug-apk` (a zip). Extract it with your Files app to get `app-debug.apk`.
6. Tap the APK, allow "Install unknown apps" for your browser/Files app when asked, then install.

## Notes
- The workflow also works if you upload the project as loose files with `.github/` intact.
- Debug APK only. Release signing and minification come in Phase 30.
- No secrets are in this project. Phase 3 will use a backend proxy and Android Keystore.
