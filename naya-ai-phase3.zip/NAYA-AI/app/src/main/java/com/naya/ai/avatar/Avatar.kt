package com.naya.ai.avatar

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.naya.ai.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

/** The 12 expressions required by the NAYA spec. */
enum class Expression(val label: String, val aura: Color) {
    Neutral("Neutral", Color(0xFF3DA9FF)),
    Happy("Happy", Color(0xFF4DD0FF)),
    Smiling("Smiling", Color(0xFF6FA8FF)),
    Laughing("Laughing", Color(0xFFFFC857)),
    Thinking("Thinking", Color(0xFF9B5CFF)),
    Confused("Confused", Color(0xFFB08CFF)),
    Surprised("Surprised", Color(0xFFFF6FD8)),
    Excited("Excited", Color(0xFFFF7A59)),
    Concerned("Concerned", Color(0xFF5C7CFF)),
    Explaining("Explaining", Color(0xFF3DFFD0)),
    Listening("Listening", Color(0xFF4DFFB0)),
    Speaking("Speaking", Color(0xFF3DA9FF)),
}

/** What the avatar should look like right now. mouthOpen is 0..1. */
data class AvatarState(
    val expression: Expression = Expression.Neutral,
    val mouthOpen: Float = 0f,
)

/** Single source of truth for the avatar. Voice/AI layers drive it, the UI observes it. */
class AvatarController {
    private val _state = MutableStateFlow(AvatarState())
    val state: StateFlow<AvatarState> = _state.asStateFlow()

    fun setExpression(e: Expression) = _state.update { it.copy(expression = e) }
    fun setMouthOpen(v: Float) = _state.update { it.copy(mouthOpen = v.coerceIn(0f, 1f)) }

    companion object {
        val shared = AvatarController()
    }
}

enum class ConversationEvent { Idle, UserGreeted, UserSpeaking, ThinkingHard, Explaining, AiSpeaking, TaskDone, Discovery, Unclear, BadNews }

object ExpressionResolver {
    fun resolve(e: ConversationEvent): Expression = when (e) {
        ConversationEvent.Idle -> Expression.Neutral
        ConversationEvent.UserGreeted -> Expression.Smiling
        ConversationEvent.UserSpeaking -> Expression.Listening
        ConversationEvent.ThinkingHard -> Expression.Thinking
        ConversationEvent.Explaining -> Expression.Explaining
        ConversationEvent.AiSpeaking -> Expression.Speaking
        ConversationEvent.TaskDone -> Expression.Excited
        ConversationEvent.Discovery -> Expression.Surprised
        ConversationEvent.Unclear -> Expression.Confused
        ConversationEvent.BadNews -> Expression.Concerned
    }

    /** Picks the expression for what NAYA is about to say, based on the reply and what the user said. */
    fun fromText(reply: String, heard: String = ""): Expression {
        val r = reply.lowercase()
        val h = heard.lowercase()
        return when {
            Regex("\\b(hello|hi|hey|namaste|namaskar)\\b").containsMatchIn(h) -> Expression.Smiling
            r.contains("sorry") || r.contains("maaf") || r.contains("couldn't") || r.contains("can't") || r.contains("error") -> Expression.Concerned
            r.contains("haha") || r.contains("😂") || r.contains("😄") -> Expression.Laughing
            r.contains("wow") || r.contains("amazing") || r.contains("surpris") -> Expression.Surprised
            r.contains("congrat") || r.contains("done") || r.contains("great") || r.startsWith("opening") ||
                r.startsWith("setting") || r.startsWith("starting") || r.startsWith("saved") -> Expression.Excited
            reply.length > 160 || reply.trimEnd().endsWith("?") -> Expression.Explaining
            else -> Expression.Happy
        }
    }
}

/** Swap point for a future Rive/Live2D renderer. */
interface AvatarRenderer {
    @Composable
    fun Render(state: AvatarState, size: Dp, modifier: Modifier)
}

object AvatarRenderers {
    var current: AvatarRenderer = StaticAvatarRenderer
}

/**
 * Image-swap face. For each expression it looks for a drawable named expr_<name> (expr_happy, expr_thinking...).
 * Optional: expr_<name>_open or naya_open (mouth open, used while speaking) and naya_blink (blink, neutral only).
 * Anything missing falls back to your original character image. Same face, images cross-fade.
 */
object StaticAvatarRenderer : AvatarRenderer {
    @Composable
    override fun Render(state: AvatarState, size: Dp, modifier: Modifier) {
        val ctx = LocalContext.current
        val base = state.expression.name.lowercase()
        fun id(name: String): Int = ctx.resources.getIdentifier(name, "drawable", ctx.packageName)
        val exprRes = remember(base) { id("expr_$base") }
        val openRes = remember(base) { id("expr_${base}_open").let { if (it != 0) it else id("naya_open") } }
        val blinkRes = remember { id("naya_blink") }

        var blink by remember { mutableStateOf(false) }
        if (blinkRes != 0) {
            LaunchedEffect(Unit) {
                while (true) {
                    delay(Random.nextLong(3000, 6000))
                    blink = true
                    delay(130)
                    blink = false
                }
            }
        }

        val target = when {
            state.mouthOpen > 0.5f && openRes != 0 -> openRes
            blink && blinkRes != 0 && state.expression == Expression.Neutral -> blinkRes
            exprRes != 0 -> exprRes
            else -> R.drawable.naya_avatar
        }

        val transition = rememberInfiniteTransition(label = "aura")
        val pulse by transition.animateFloat(
            initialValue = 0.88f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulse",
        )
        val breathe by transition.animateFloat(
            initialValue = 1f,
            targetValue = 1.015f,
            animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "breathe",
        )
        val aura by animateColorAsState(state.expression.aura, tween(500), label = "auraColor")
        val talk = 1f + state.mouthOpen * 0.015f

        Box(modifier.size(size), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(size)
                    .scale(pulse)
                    .background(Brush.radialGradient(listOf(aura.copy(alpha = 0.55f), Color.Transparent)), CircleShape),
            )
            Crossfade(targetState = target, animationSpec = tween(220), label = "face") { res ->
                Image(
                    painter = painterResource(res),
                    contentDescription = "NAYA",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(size * 0.82f)
                        .scale(breathe * talk)
                        .clip(CircleShape)
                        .border(2.dp, aura, CircleShape),
                )
            }
        }
    }
}

@Composable
fun NayaAvatarView(state: AvatarState, size: Dp, modifier: Modifier = Modifier) {
    AvatarRenderers.current.Render(state, size, modifier)
}
