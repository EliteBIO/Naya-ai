package com.naya.ai.core

import kotlinx.coroutines.flow.Flow

/*
 * Provider contracts. Phase 1 ships interfaces only (no implementations),
 * so later phases can plug in services without touching the UI.
 */

data class ChatTurn(val role: String, val text: String)

/** Phase 2 - AI conversation (streamed through a secure backend proxy). */
interface AiProvider {
    val id: String
    val displayName: String
    fun streamChat(model: String, history: List<ChatTurn>): Flow<String>
}

/** Phase 5 - image generation. */
interface ImageProvider {
    val id: String
    suspend fun generate(prompt: String, style: String?): ByteArray
}

sealed interface VideoJobStatus {
    data object Pending : VideoJobStatus
    data class Done(val url: String) : VideoJobStatus
    data class Failed(val reason: String) : VideoJobStatus
}

/** Phase 6 - video generation (asynchronous jobs). */
interface VideoProvider {
    val id: String
    suspend fun submit(prompt: String, aspectRatio: String): String
    suspend fun status(jobId: String): VideoJobStatus
}

/** Phase 3 - speech. */
interface SpeechInput {
    fun start(languageTag: String, onText: (String) -> Unit, onError: (String) -> Unit)
    fun stop()
}

interface SpeechOutput {
    fun speak(text: String, speed: Float, pitch: Float, onDone: () -> Unit)
    fun stop()
}
