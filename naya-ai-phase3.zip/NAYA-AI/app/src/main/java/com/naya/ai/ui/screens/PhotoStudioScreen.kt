package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import android.content.Context
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun loadBitmap(ctx: Context, uri: Uri): ImageBitmap? = runCatching {
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        val big = maxOf(info.size.width, info.size.height)
        decoder.setTargetSampleSize(maxOf(1, big / 1024))
    }.asImageBitmap()
}.getOrNull()

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PhotoStudioScreen() {
    val ctx = LocalContext.current
    var prompt by rememberSaveable { mutableStateOf("") }
    var style by rememberSaveable { mutableStateOf("Realistic") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<ImageBitmap?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri = it }
    LaunchedEffect(uri) {
        preview = uri?.let { u -> withContext(Dispatchers.IO) { loadBitmap(ctx, u) } }
    }

    ScreenColumn {
        ScreenHeader("Photo Studio", "Image generation and editing")
        StatusBadge("Generation: awaiting image provider + API key (Phase 5)")

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Describe the image (draft, not sent anywhere yet)") },
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
            minLines = 3,
        )

        SectionTitle("Style")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Realistic", "Anime", "Cinematic", "3D Render", "Neon", "Watercolor").forEach { s ->
                FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s) }, colors = nayaChipColors())
            }
        }

        SectionTitle("Source image")
        NeonButton("Pick image from gallery") {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        val bmp = preview
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = "Selected image",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp).clip(RoundedCornerShape(16.dp)),
            )
        } else if (uri != null) {
            Text("Couldn't open that image. Try another file.", color = NayaColors.Warn, fontSize = 13.sp)
        }

        NeonButton("Generate image", Modifier.fillMaxWidth(), enabled = false) {}
        FeatureList(
            listOf(
                Feature("Pick image and preview", "Working", working = true),
                Feature("Text-to-image", "Phase 5"),
                Feature("Image-to-image and AI editing", "Phase 5"),
                Feature("Enhance, restore, remove background", "Phase 5"),
                Feature("Prompt improvement", "Phase 5"),
                Feature("Save, share, generation history", "Phase 5"),
            ),
        )
        Spacer(Modifier.height(8.dp))
    }
}
