package com.naya.ai.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.dp
import com.naya.ai.ui.theme.NayaColors

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.clip(shape).background(NayaColors.Glass).border(1.dp, NayaColors.GlassBorder, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun StatusBadge(text: String, color: Color = NayaColors.Warn) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), shape)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .alpha(if (enabled) 1f else 0.35f)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(NayaColors.Blue, NayaColors.Purple)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun IconTextButton(glyph: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(NayaColors.Glass).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(glyph, fontSize = 20.sp, color = NayaColors.TextPrimary) }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconTextButton("←", onBack)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = NayaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = NayaColors.TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = NayaColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content,
    )
}

data class Feature(val name: String, val status: String, val working: Boolean = false)

@Composable
fun FeatureList(features: List<Feature>) {
    GlassCard(Modifier.fillMaxWidth()) {
        features.forEach { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(f.name, Modifier.weight(1f).padding(end = 8.dp), color = NayaColors.TextPrimary, fontSize = 14.sp)
                StatusBadge(f.status, if (f.working) NayaColors.Ok else NayaColors.Warn)
            }
        }
    }
}

@Composable
fun nayaFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NayaColors.Blue,
    unfocusedBorderColor = NayaColors.GlassBorder,
    focusedTextColor = NayaColors.TextPrimary,
    unfocusedTextColor = NayaColors.TextPrimary,
    cursorColor = NayaColors.Blue,
    focusedPlaceholderColor = NayaColors.TextDim,
    unfocusedPlaceholderColor = NayaColors.TextDim,
    focusedLabelColor = NayaColors.Blue,
    unfocusedLabelColor = NayaColors.TextDim,
)

@Composable
fun nayaChipColors() = FilterChipDefaults.filterChipColors(
    labelColor = NayaColors.TextDim,
    selectedContainerColor = NayaColors.Navy2,
    selectedLabelColor = NayaColors.Blue,
)
