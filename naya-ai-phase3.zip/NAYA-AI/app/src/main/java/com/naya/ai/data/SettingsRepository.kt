package com.naya.ai.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSettings(
    val displayName: String = "",
    val language: String = "hinglish", // english | hindi | hinglish
    val speechSpeed: Float = 1f,
    val speechPitch: Float = 1f,
    val model: String = "gemini-3.5-flash",
)

/** Local-only settings store (SharedPreferences). No secrets here (the API key lives in SecureKeyStore). */
class SettingsRepository private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("naya_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun load() = UserSettings(
        displayName = prefs.getString("name", "") ?: "",
        language = prefs.getString("lang", "hinglish") ?: "hinglish",
        speechSpeed = prefs.getFloat("speed", 1f),
        speechPitch = prefs.getFloat("pitch", 1f),
        model = prefs.getString("model", "gemini-3.5-flash") ?: "gemini-3.5-flash",
    )

    fun update(change: (UserSettings) -> UserSettings) {
        val s = change(_settings.value)
        _settings.value = s
        prefs.edit()
            .putString("name", s.displayName)
            .putString("lang", s.language)
            .putFloat("speed", s.speechSpeed)
            .putFloat("pitch", s.speechPitch)
            .putString("model", s.model)
            .apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
        _settings.value = UserSettings()
    }

    companion object {
        @Volatile
        private var instance: SettingsRepository? = null

        fun get(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}
