package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.compose.ui.platform.LocalContext
import com.naya.ai.tools.DeviceCommands
import com.naya.ai.tools.NotesStore
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun ToolsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val battery = remember {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "Unavailable"
    }
    val now = remember { LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) }
    val notesStore = remember { NotesStore(ctx) }
    var notes by remember { mutableStateOf(notesStore.list()) }
    var cmd by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }

    ScreenColumn {
        ScreenHeader("Tools", "Control your phone with commands", onBack)

        SectionTitle("Try a command")
        OutlinedTextField(
            value = cmd,
            onValueChange = { cmd = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("e.g. open YouTube, torch on, alarm 7 am") },
            singleLine = true,
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
        )
        NeonButton("Run", Modifier.fillMaxWidth(), enabled = cmd.isNotBlank()) {
            val r = DeviceCommands.handle(ctx, cmd.trim())
            result = r?.reply ?: "That isn't a device command. Ask it in Chat instead."
            notes = notesStore.list()
        }
        if (result.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) { Text(result, color = NayaColors.TextPrimary) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "Open any app · alarm 7:30 am · timer 5 minutes · torch on/off · battery · what time is it · " +
                    "call 9876543210 (opens dialer) · navigate to Delhi · google best phones · open wifi settings · " +
                    "note: buy milk · calculate 12 times 5.\nThe same commands work by voice and in Chat.",
                color = NayaColors.TextDim, fontSize = 12.sp,
            )
        }

        SectionTitle("Notes")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = noteInput,
                onValueChange = { noteInput = it },
                modifier = Modifier.weight(1f),
                label = { Text("New note") },
                singleLine = true,
                colors = nayaFieldColors(),
                shape = RoundedCornerShape(16.dp),
            )
            Spacer(Modifier.width(8.dp))
            NeonButton("Add", enabled = noteInput.isNotBlank()) {
                notesStore.add(noteInput.trim())
                noteInput = ""
                notes = notesStore.list()
            }
        }
        if (notes.isEmpty()) {
            Text("No notes yet.", color = NayaColors.TextDim, fontSize = 13.sp)
        } else {
            notes.forEachIndexed { i, n ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(n, Modifier.weight(1f), color = NayaColors.TextPrimary, fontSize = 14.sp)
                        Text("✕", Modifier.clickable { notesStore.delete(i); notes = notesStore.list() }.padding(8.dp), color = NayaColors.Warn)
                    }
                }
            }
        }

        SectionTitle("This device")
        GlassCard(Modifier.fillMaxWidth()) {
            InfoRow("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
            InfoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            InfoRow("Battery", battery)
            InfoRow("Date and time", now)
        }
        FeatureList(
            listOf(
                Feature("Open apps, alarms, timers, torch", "Working", working = true),
                Feature("Call (opens dialer), maps, web search", "Working", working = true),
                Feature("Notes and calculator", "Working", working = true),
                Feature("Auto-tap or control other apps", "Not supported"),
            ),
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = NayaColors.TextDim, fontSize = 13.sp)
        Text(value, color = NayaColors.TextPrimary, fontSize = 13.sp)
    }
}
