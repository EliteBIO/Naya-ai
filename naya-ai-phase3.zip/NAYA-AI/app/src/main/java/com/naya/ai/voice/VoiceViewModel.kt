package com.naya.ai.voice

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.naya.ai.avatar.AvatarController
import com.naya.ai.avatar.Expression
import com.naya.ai.avatar.ExpressionResolver
import com.naya.ai.data.SettingsRepository
import com.naya.ai.ui.ChatEvent
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

enum class VoicePhase { Idle, Listening, Thinking, Speaking }

data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.Idle,
    val partial: String = "",
    val heard: String = "",
    val reply: String = "",
    val note: String = "",
    val level: Float = 0f,
    val muted: Boolean = false,
    val live: Boolean = false,
)

/**
 * Voice conversation: Android SpeechRecognizer (speech to text) -> AI/command pipeline in ChatViewModel
 * -> Android TextToSpeech (text to speech). Drives the avatar expression and an approximate mouth flap.
 * Audio is only captured while the screen is open and you started listening. Nothing runs in the background.
 */
class VoiceViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = SettingsRepository.get(app)
    private val avatar = AvatarController.shared

    private val _ui = MutableStateFlow(VoiceUiState())
    val ui: StateFlow<VoiceUiState> = _ui.asStateFlow()

    /** Set by the screen: sends recognized text into the chat/AI pipeline. */
    var sendToAi: (String) -> Unit = {}

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var mouthJob: Job? = null

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            viewModelScope.launch { finishSpeaking() }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            viewModelScope.launch { finishSpeaking() }
        }
    }

    init {
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.setOnUtteranceProgressListener(utteranceListener)
        }
    }

    fun setNote(n: String) = _ui.update { it.copy(note = n) }

    fun toggleLive() = _ui.update { it.copy(live = !it.live) }

    fun toggleMute() {
        _ui.update { it.copy(muted = !it.muted) }
        if (_ui.value.muted) stopSpeaking()
    }

    private fun recognitionTag(): String =
        if (settings.settings.value.language == "english") "en-IN" else "hi-IN"

    fun startListening() {
        val app = getApplication<Application>()
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            setNote("Speech recognition isn't available on this phone. Install or enable the Google app.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                _ui.update { it.copy(level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                _ui.update { it.copy(level = 0f) }
            }
            override fun onError(error: Int) = handleError(error)
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handleHeard(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (p.isNotEmpty()) _ui.update { it.copy(partial = p) }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer = r
        _ui.update { it.copy(phase = VoicePhase.Listening, partial = "", note = "") }
        avatar.setExpression(Expression.Listening)
        r.startListening(intent)
    }

    fun stopListening() {
        recognizer?.stopListening()
    }

    private fun handleHeard(text: String) {
        if (text.isBlank()) {
            _ui.update { it.copy(phase = VoicePhase.Idle, level = 0f, note = "I didn't catch that. Tap the mic and try again.") }
            avatar.setExpression(Expression.Confused)
            return
        }
        _ui.update { it.copy(phase = VoicePhase.Thinking, heard = text, partial = "", reply = "", level = 0f, note = "") }
        avatar.setExpression(Expression.Thinking)
        sendToAi(text)
    }

    private fun handleError(code: Int) {
        val msg = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Tap the mic and try again."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs internet on this phone."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The recognizer is busy. Try again."
            else -> "Speech error ($code). Try again."
        }
        _ui.update { it.copy(phase = VoicePhase.Idle, level = 0f, note = msg) }
        avatar.setExpression(Expression.Confused)
    }

    /** Called with each finished AI/command reply while this screen is open. */
    fun onAiEvent(ev: ChatEvent) {
        if (_ui.value.phase != VoicePhase.Thinking) return
        if (!ev.ok) {
            _ui.update { it.copy(phase = VoicePhase.Idle, note = ev.text) }
            avatar.setExpression(Expression.Concerned)
            return
        }
        _ui.update { it.copy(reply = ev.text, note = "") }
        speak(ev.text)
    }

    private fun speak(text: String) {
        val expr = ExpressionResolver.fromText(text, _ui.value.heard)
        val engine = tts
        if (_ui.value.muted || !ttsReady || engine == null) {
            avatar.setExpression(expr)
            _ui.update { it.copy(phase = VoicePhase.Idle, note = if (!_ui.value.muted) "The voice engine isn't ready." else "") }
            viewModelScope.launch {
                delay(2500)
                if (_ui.value.phase == VoicePhase.Idle) avatar.setExpression(Expression.Neutral)
            }
            return
        }
        val s = settings.settings.value
        val locale = if (s.language == "hindi") Locale("hi", "IN") else Locale("en", "IN")
        runCatching {
            engine.setLanguage(locale)
            val voices = engine.voices?.filter { it.locale.language == locale.language }.orEmpty()
            val pick = voices.firstOrNull { it.name.contains("female", true) && !it.isNetworkConnectionRequired }
                ?: voices.firstOrNull { it.name.contains("female", true) }
            if (pick != null) engine.setVoice(pick)
            engine.setSpeechRate(s.speechSpeed)
            engine.setPitch(s.speechPitch)
        }
        avatar.setExpression(expr)
        _ui.update { it.copy(phase = VoicePhase.Speaking) }
        startMouth()
        engine.speak(clean(text), TextToSpeech.QUEUE_FLUSH, null, "naya")
    }

    private fun clean(text: String): String =
        text.replace(Regex("\\[(.*?)]\\(.*?\\)"), "\$1")
            .replace(Regex("[*_#`>~|]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(3500)

    private fun startMouth() {
        mouthJob?.cancel()
        mouthJob = viewModelScope.launch {
            var open = false
            while (isActive) {
                open = !open
                avatar.setMouthOpen(if (open) 0.55f + Random.nextFloat() * 0.45f else 0.1f)
                delay(110)
            }
        }
    }

    private fun finishSpeaking() {
        mouthJob?.cancel()
        avatar.setMouthOpen(0f)
        avatar.setExpression(Expression.Neutral)
        _ui.update { it.copy(phase = VoicePhase.Idle) }
        if (_ui.value.live) startListening()
    }

    fun stopSpeaking() {
        tts?.stop()
        mouthJob?.cancel()
        avatar.setMouthOpen(0f)
        if (_ui.value.phase == VoicePhase.Speaking) {
            _ui.update { it.copy(phase = VoicePhase.Idle) }
            avatar.setExpression(Expression.Neutral)
        }
    }

    /** Stops everything (used when the voice screen closes). */
    fun stopAll() {
        tts?.stop()
        mouthJob?.cancel()
        recognizer?.destroy()
        recognizer = null
        avatar.setMouthOpen(0f)
        avatar.setExpression(Expression.Neutral)
        _ui.update { VoiceUiState(muted = it.muted) }
    }

    override fun onCleared() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onCleared()
    }
}
