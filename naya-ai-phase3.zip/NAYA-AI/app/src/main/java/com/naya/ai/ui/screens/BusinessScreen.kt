package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*

@Composable
fun BusinessScreen(onBack: () -> Unit) {
    ScreenColumn {
        ScreenHeader("Business", "Customer and order tools", onBack)
        StatusBadge("Module awaiting Phase 9")
        FeatureList(
            listOf(
                Feature("Customer records", "Phase 9"),
                Feature("Order management", "Phase 9"),
                Feature("Business notes", "Phase 9"),
                Feature("Customer support assistant", "Phase 9"),
                Feature("Marketing and drafts", "Phase 9"),
                Feature("Basic analytics and CSV export", "Phase 9"),
            ),
        )
    }
}
