package com.naya.ai.ui.theme

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object NayaColors {
    val Void = Color(0xFF03060F)
    val Navy = Color(0xFF0A1330)
    val Navy2 = Color(0xFF14235A)
    val Blue = Color(0xFF3DA9FF)
    val Purple = Color(0xFF9B5CFF)
    val Glass = Color(0x1AFFFFFF)
    val GlassBorder = Color(0x33FFFFFF)
    val TextPrimary = Color(0xFFEAF2FF)
    val TextDim = Color(0xFF8FA3C8)
    val Warn = Color(0xFFFFB84D)
    val Ok = Color(0xFF4DFFB0)
}

private val NayaScheme = darkColorScheme(
    primary = NayaColors.Blue,
    onPrimary = NayaColors.Void,
    secondary = NayaColors.Purple,
    background = NayaColors.Void,
    onBackground = NayaColors.TextPrimary,
    surface = NayaColors.Navy,
    onSurface = NayaColors.TextPrimary,
    surfaceVariant = NayaColors.Navy2,
    onSurfaceVariant = NayaColors.TextDim,
)

@Composable
fun NayaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NayaScheme, content = content)
}

fun Modifier.nayaBackground(): Modifier =
    background(Brush.verticalGradient(listOf(NayaColors.Void, NayaColors.Navy, NayaColors.Void)))
