package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.avatar.AvatarState
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.naya.ai.ui.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onProfile: () -> Unit) {
    val s by vm.settings.collectAsState()
    val sliderColors = SliderDefaults.colors(thumbColor = NayaColors.Blue, activeTrackColor = NayaColors.Blue)

    ScreenColumn {
        ScreenHeader("Settings", null, onBack)

        GlassCard(Modifier.fillMaxWidth(), onClick = onProfile) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NayaAvatarView(AvatarState(), 64.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (s.displayName.isBlank()) "Set up your profile" else s.displayName,
                        color = NayaColors.TextPrimary, fontWeight = FontWeight.SemiBold,
                    )
                    Text("Tap to edit profile", color = NayaColors.TextDim, fontSize = 12.sp)
                }
                Text("›", color = NayaColors.TextDim, fontSize = 24.sp)
            }
        }

        SectionTitle("Language")
        Text("Saved now. Used by AI and voice from Phase 2–3.", color = NayaColors.TextDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("english" to "English", "hindi" to "हिन्दी", "hinglish" to "Hinglish").forEach { (key, label) ->
                FilterChip(
                    selected = s.language == key,
                    onClick = { vm.repo.update { it.copy(language = key) } },
                    label = { Text(label) },
                    colors = nayaChipColors(),
                )
            }
        }

        SectionTitle("Voice")
        Text("Speed ${"%.1f".format(s.speechSpeed)}x", color = NayaColors.TextPrimary, fontSize = 13.sp)
        Slider(
            value = s.speechSpeed,
            onValueChange = { v -> vm.repo.update { it.copy(speechSpeed = v) } },
            valueRange = 0.5f..2f,
            colors = sliderColors,
        )
        Text("Pitch ${"%.1f".format(s.speechPitch)}", color = NayaColors.TextPrimary, fontSize = 13.sp)
        Slider(
            value = s.speechPitch,
            onValueChange = { v -> vm.repo.update { it.copy(speechPitch = v) } },
            valueRange = 0.5f..2f,
            colors = sliderColors,
        )
        StatusBadge("Used for NAYA's spoken voice")

        SectionTitle("AI provider: Google Gemini")
        var hasKey by remember { mutableStateOf(vm.secure.hasKey()) }
        var keyInput by remember { mutableStateOf("") }
        var modelInput by remember(s.model) { mutableStateOf(s.model) }
        if (hasKey) StatusBadge("API key saved (encrypted on this phone)", NayaColors.Ok) else StatusBadge("No API key yet")
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it.trim() },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Paste Gemini API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Save key", enabled = keyInput.length > 10) {
                vm.secure.saveKey(keyInput)
                keyInput = ""
                hasKey = true
            }
            if (hasKey) NeonButton("Remove key") {
                vm.secure.clear()
                hasKey = false
            }
        }
        OutlinedTextField(
            value = modelInput,
            onValueChange = { modelInput = it.trim() },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Model name") },
            singleLine = true,
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
        )
        NeonButton("Save model", enabled = modelInput.isNotBlank() && modelInput != s.model) {
            vm.repo.update { it.copy(model = modelInput) }
        }
        Text(
            "Get a free key at aistudio.google.com. If chat says 'model not found', change the model name here.",
            color = NayaColors.TextDim, fontSize = 12.sp,
        )

        SectionTitle("Coming in later phases")
        FeatureList(
            listOf(
                Feature("More providers (OpenAI, Claude)", "Later"),
                Feature("Pick a specific voice", "Later"),
                Feature("Notifications", "Phase 7"),
                Feature("Memory controls", "Phase 9"),
                Feature("Theme options", "Phase 10"),
            ),
        )

        SectionTitle("Privacy")
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "Your name, language and voice sliders stay on this device. Your Gemini key is stored encrypted on this phone. " +
                    "When you send a chat message, it is sent to Google Gemini to get a reply. Chats are saved only on this phone. " +
                    "The microphone is used only while you tap the mic in the Avatar screen, and speech is recognized by Google's speech service on your phone. No camera access, no analytics.",
                color = NayaColors.TextDim, fontSize = 13.sp,
            )
        }
        NeonButton("Reset all settings", Modifier.fillMaxWidth()) { vm.repo.reset() }

        SectionTitle("About")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("NAYA AI", color = NayaColors.TextPrimary, fontWeight = FontWeight.Bold)
            Text("Your personal AI", color = NayaColors.TextDim, fontSize = 12.sp)
            Text("Version 0.3.0 (Phase 3)", color = NayaColors.TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
