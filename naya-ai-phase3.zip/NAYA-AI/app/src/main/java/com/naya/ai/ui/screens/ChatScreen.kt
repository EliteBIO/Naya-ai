package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.data.ChatMessage
import com.naya.ai.ui.ChatViewModel
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val ui by vm.ui.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val msgs = ui.current.messages
    val lastLen = msgs.lastOrNull()?.text?.length ?: 0

    LaunchedEffect(msgs.size, lastLen, ui.showHistory) {
        if (!ui.showHistory && msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AI Chat", color = NayaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (ui.showHistory) "Saved conversations" else ui.current.title.ifBlank { "New conversation" },
                    color = NayaColors.TextDim, fontSize = 12.sp, maxLines = 1,
                )
            }
            IconTextButton("🕘") { vm.toggleHistory() }
            Spacer(Modifier.width(8.dp))
            IconTextButton("+") { vm.newChat() }
        }
        if (vm.hasKey()) StatusBadge("Gemini ready", NayaColors.Ok) else StatusBadge("No API key. Add it in Settings")
        Spacer(Modifier.height(10.dp))

        if (ui.showHistory) {
            if (ui.all.isEmpty()) {
                Text("No saved chats yet.", color = NayaColors.TextDim)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ui.all, key = { it.id }) { c ->
                    GlassCard(Modifier.fillMaxWidth(), onClick = { vm.open(c.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.title.ifBlank { "Untitled" }, color = NayaColors.TextPrimary, maxLines = 1)
                                Text("${c.messages.size} messages", color = NayaColors.TextDim, fontSize = 12.sp)
                            }
                            Text("✕", Modifier.clickable { vm.delete(c.id) }.padding(8.dp), color = NayaColors.Warn)
                        }
                    }
                }
            }
        } else {
            if (msgs.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Say hi to NAYA 👋", color = NayaColors.TextDim)
                }
            } else {
                LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(msgs, key = { it.id }) { Bubble(it) }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message NAYA…") },
                    colors = nayaFieldColors(),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4,
                )
                Spacer(Modifier.width(8.dp))
                NeonButton("Send", enabled = input.isNotBlank() && !ui.sending) {
                    vm.send(input.trim())
                    input = ""
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val shape = RoundedCornerShape(18.dp)
    val tint = when {
        m.isSystem -> NayaColors.Warn
        m.fromUser -> NayaColors.Blue
        else -> NayaColors.Purple
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Text(
            m.text.ifEmpty { "…" },
            color = NayaColors.TextPrimary,
            fontSize = 14.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(tint.copy(alpha = 0.18f), shape)
                .border(1.dp, tint.copy(alpha = 0.45f), shape)
                .padding(12.dp),
        )
    }
}
