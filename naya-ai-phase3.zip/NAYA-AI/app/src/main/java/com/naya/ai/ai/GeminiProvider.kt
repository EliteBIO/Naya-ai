package com.naya.ai.ai

import com.naya.ai.core.AiProvider
import com.naya.ai.core.ChatTurn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AiException(message: String) : Exception(message)

/** Google Gemini over HTTPS with streamed (SSE) responses. The key is sent in a header, never in the URL. */
class GeminiProvider(
    private val apiKey: String,
    private val systemPrompt: String,
) : AiProvider {
    override val id = "gemini"
    override val displayName = "Google Gemini"

    override fun streamChat(model: String, history: List<ChatTurn>): Flow<String> = flow {
        val contents = JSONArray()
        history.forEach { t ->
            contents.put(
                JSONObject()
                    .put("role", t.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", t.text))),
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:streamGenerateContent?alt=sse")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != 200) {
                val err = runCatching { conn.errorStream?.bufferedReader()?.readText() }.getOrNull().orEmpty()
                throw AiException(friendly(code, err))
            }
            val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            reader.use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val text = extractText(line.removePrefix("data:").trim())
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } finally {
            conn.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    private fun extractText(json: String): String {
        if (json.isEmpty() || json == "[DONE]") return ""
        return runCatching {
            val parts = JSONObject(json).optJSONArray("candidates")
                ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return@runCatching ""
            buildString {
                for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text", "") ?: "")
            }
        }.getOrDefault("")
    }

    private fun friendly(code: Int, err: String): String {
        val detail = runCatching { JSONObject(err).getJSONObject("error").getString("message") }
            .getOrDefault("").take(200)
        val hint = when (code) {
            400 -> "The request was rejected. The key may be invalid, or the free tier may not be available in your country."
            401, 403 -> "The API key was refused. Check it in Settings."
            404 -> "Model not found. Change the model name in Settings."
            429 -> "Free limit reached. Wait a bit and try again."
            else -> "Server error ($code)."
        }
        return if (detail.isBlank()) hint else "$hint\n($detail)"
    }
}
