package com.naya.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.naya.ai.ai.AiException
import com.naya.ai.ai.GeminiProvider
import com.naya.ai.core.ChatTurn
import com.naya.ai.data.ChatMessage
import com.naya.ai.data.ChatStore
import com.naya.ai.data.Conversation
import com.naya.ai.data.SecureKeyStore
import com.naya.ai.data.SettingsRepository
import com.naya.ai.tools.DeviceCommands
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

data class ChatUiState(
    val current: Conversation,
    val all: List<Conversation> = emptyList(),
    val sending: Boolean = false,
    val showHistory: Boolean = false,
)

/** A finished reply (AI answer or device-command result). ok=false means an error message. */
data class ChatEvent(val text: String, val ok: Boolean)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ChatStore(app)
    private val settingsRepo = SettingsRepository.get(app)
    private val secure = SecureKeyStore(app)

    private var nextId = System.currentTimeMillis()
    private fun newId() = nextId++
    private fun newConv() = Conversation(newId(), "", System.currentTimeMillis(), emptyList())

    private val _ui = MutableStateFlow(ChatUiState(current = newConv()))
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()

    private val _events = MutableSharedFlow<ChatEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<ChatEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { store.load() }
            _ui.update { it.copy(all = saved) }
        }
    }

    fun hasKey(): Boolean = secure.hasKey()

    fun toggleHistory() = _ui.update { it.copy(showHistory = !it.showHistory) }

    fun newChat() {
        if (_ui.value.sending) return
        _ui.update { it.copy(current = newConv(), showHistory = false) }
    }

    fun open(id: Long) {
        if (_ui.value.sending) return
        _ui.update { s ->
            val found = s.all.firstOrNull { it.id == id }
            if (found != null) s.copy(current = found, showHistory = false) else s
        }
    }

    fun delete(id: Long) {
        if (_ui.value.sending) return
        val list = _ui.value.all.filter { it.id != id }
        _ui.update { s -> s.copy(all = list, current = if (s.current.id == id) newConv() else s.current) }
        viewModelScope.launch(Dispatchers.IO) { store.save(list) }
    }

    /** Text or voice input. Device commands run locally first; everything else goes to the AI. */
    fun send(text: String, spoken: Boolean = false) {
        if (_ui.value.sending) return
        val userMsg = ChatMessage(newId(), true, text)

        val cmd = DeviceCommands.handle(getApplication<Application>(), text)
        if (cmd != null) {
            setCurrent { c ->
                c.copy(
                    title = if (c.title.isBlank()) text.take(30) else c.title,
                    messages = c.messages + userMsg + ChatMessage(newId(), false, cmd.reply),
                )
            }
            persist()
            _events.tryEmit(ChatEvent(cmd.reply, true))
            return
        }

        val key = secure.getKey()
        if (key == null) {
            val notice = if (secure.hasKey()) "Couldn't read the saved API key. Please save it again in Settings."
            else "No API key yet. Add your Gemini key in Settings."
            setCurrent { c -> c.copy(messages = c.messages + userMsg + ChatMessage(newId(), false, notice, true)) }
            _events.tryEmit(ChatEvent(notice, false))
            return
        }

        val replyId = newId()
        setCurrent { c ->
            c.copy(
                title = if (c.title.isBlank()) text.take(30) else c.title,
                messages = c.messages + userMsg + ChatMessage(replyId, false, ""),
            )
        }
        _ui.update { it.copy(sending = true) }

        val s = settingsRepo.settings.value
        val history = _ui.value.current.messages
            .filter { !it.isSystem && it.id != replyId }
            .takeLast(20)
            .map { ChatTurn(if (it.fromUser) "user" else "model", it.text) }

        viewModelScope.launch {
            try {
                GeminiProvider(key, persona(s.language, spoken)).streamChat(s.model, history).collect { chunk ->
                    setCurrent { c ->
                        c.copy(messages = c.messages.map { if (it.id == replyId) it.copy(text = it.text + chunk) else it })
                    }
                }
                val reply = _ui.value.current.messages.firstOrNull { it.id == replyId }
                if (reply == null || reply.text.isBlank()) {
                    failReply(replyId, AiException("The AI returned an empty reply. Try rephrasing."))
                } else {
                    _events.tryEmit(ChatEvent(reply.text, true))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failReply(replyId, e)
            } finally {
                _ui.update { it.copy(sending = false) }
                persist()
            }
        }
    }

    private fun failReply(replyId: Long, e: Exception) {
        val msg = when (e) {
            is AiException -> e.message ?: "AI error"
            is IOException -> "Couldn't reach the internet. Check your connection and try again."
            else -> "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
        }
        setCurrent { c ->
            val reply = c.messages.firstOrNull { it.id == replyId }
            if (reply != null && reply.text.isBlank()) {
                c.copy(messages = c.messages.map { if (it.id == replyId) it.copy(text = msg, isSystem = true) else it })
            } else {
                c.copy(messages = c.messages + ChatMessage(newId(), false, msg, true))
            }
        }
        _events.tryEmit(ChatEvent(msg, false))
    }

    private fun setCurrent(f: (Conversation) -> Conversation) = _ui.update { it.copy(current = f(it.current)) }

    private fun persist() {
        val s = _ui.value
        val saved = s.current.copy(updated = System.currentTimeMillis(), messages = s.current.messages.filter { !it.isSystem })
        if (saved.messages.isEmpty()) return
        val list = (listOf(saved) + s.all.filter { it.id != saved.id }).sortedByDescending { it.updated }
        _ui.update { it.copy(all = list) }
        viewModelScope.launch(Dispatchers.IO) { store.save(list) }
    }

    private fun persona(lang: String, spoken: Boolean): String {
        val l = when (lang) {
            "english" -> "English"
            "hindi" -> "Hindi (Devanagari script)"
            else -> "Hinglish (Hindi written in Roman letters mixed with English), matching the user's style"
        }
        val base = "You are NAYA, a friendly, intelligent and professional female AI assistant inside the NAYA AI Android app. " +
            "Reply in $l unless the user clearly writes in another language. Keep answers clear and reasonably short."
        return if (spoken) {
            base + " The user is talking to you by voice. Reply in one to three short sentences of plain text. No markdown, no lists, no emojis."
        } else base
    }
}
