package com.naya.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves conversations as a JSON file in the app's private storage (works offline). */
class ChatStore(context: Context) {
    private val file = File(context.filesDir, "chats.json")

    @Synchronized
    fun load(): List<Conversation> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(file.readText())
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val ms = o.getJSONArray("m")
                Conversation(
                    id = o.getLong("id"),
                    title = o.getString("t"),
                    updated = o.getLong("u"),
                    messages = List(ms.length()) { j ->
                        val m = ms.getJSONObject(j)
                        ChatMessage(m.getLong("id"), m.getBoolean("user"), m.getString("x"))
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun save(list: List<Conversation>) {
        runCatching {
            val arr = JSONArray()
            list.forEach { c ->
                val ms = JSONArray()
                c.messages.forEach { m ->
                    ms.put(JSONObject().put("id", m.id).put("user", m.fromUser).put("x", m.text))
                }
                arr.put(JSONObject().put("id", c.id).put("t", c.title).put("u", c.updated).put("m", ms))
            }
            file.writeText(arr.toString())
        }
    }
}
