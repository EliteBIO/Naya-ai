package com.naya.ai.tools

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class CommandResult(val reply: String)

/**
 * Local command router for typed or spoken text. Returns null when the text is not a device command
 * (the caller then sends it to the AI). Everything here uses normal Android intents: no hidden control,
 * and alarms/calls open the system app so the user confirms.
 */
object DeviceCommands {

    private val hindiMap = listOf(
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "क्रोम" to "chrome", "सेटिंग्स" to "settings", "सेटिंग" to "settings",
        "गैलरी" to "gallery", "गूगल" to "google", "कैलकुलेटर" to "calculator", "घड़ी" to "clock",
        "अलार्म" to "alarm", "टाइमर" to "timer", "टॉर्च" to "torch", "बैटरी" to "battery",
        "खोल दो" to "kholo", "खोलो" to "kholo", "चालू करो" to "on", "बंद करो" to "off",
    )

    fun handle(ctx: Context, raw: String): CommandResult? {
        val t = normalize(raw)
        if (t.isBlank() || t.length > 160) return null
        return tryNote(ctx, raw)
            ?: tryCalc(t)
            ?: tryAlarm(ctx, t)
            ?: tryTimer(ctx, t)
            ?: tryTorch(ctx, t)
            ?: tryInfo(ctx, t)
            ?: tryCall(ctx, t)
            ?: tryNavigate(ctx, t)
            ?: trySearch(ctx, t)
            ?: tryOpen(ctx, t)
    }

    private fun normalize(s: String): String {
        var t = s.lowercase().trim().trimEnd('.', '!', '?', '।')
        for ((a, b) in hindiMap) t = t.replace(a, b)
        return t.replace(Regex("\\s+"), " ")
    }

    private fun start(ctx: Context, i: Intent): Boolean =
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)

    // ---- notes ----
    private fun tryNote(ctx: Context, raw: String): CommandResult? {
        val m = Regex("^(?:note|save note|add note|note karo|yaad rakho|yaad rakh)\\s*[:,-]?\\s+(.+)$", RegexOption.IGNORE_CASE)
            .find(raw.trim()) ?: return null
        NotesStore(ctx).add(m.groupValues[1].trim())
        return CommandResult("Saved your note.")
    }

    // ---- calculator ----
    private fun tryCalc(t: String): CommandResult? {
        var e = t.replace(Regex("^(?:calculate|calc|hisab karo|hisab|what is|what's|kitna hota hai)\\s+"), "")
        e = e.replace("multiplied by", "*").replace("divided by", "/").replace("times", "*")
            .replace("into", "*").replace("plus", "+").replace("minus", "-")
            .replace("÷", "/").replace("×", "*")
        e = e.replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*")
        if (!e.matches(Regex("[0-9+\\-*/().\\s]+"))) return null
        if (!e.any { it.isDigit() } || !e.any { it in "+-*/" }) return null
        val v = Calc.eval(e) ?: return CommandResult("I couldn't work that out.")
        return CommandResult("${e.trim()} = ${fmt(v)}")
    }

    private fun fmt(v: Double): String =
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else "%.4f".format(v).trimEnd('0').trimEnd('.')

    // ---- alarm / timer ----
    private fun tryAlarm(ctx: Context, t: String): CommandResult? {
        if (!t.contains("alarm")) return null
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?(?:\\s*(am|pm|baje|bje)\\b)?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3]
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        if (h > 23 || min > 59) return CommandResult("That time doesn't look right.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "NAYA")
        return if (start(ctx, i)) CommandResult("Setting an alarm for %02d:%02d. Please confirm it in the clock app.".format(h, min))
        else CommandResult("I couldn't open the clock app.")
    }

    private fun tryTimer(ctx: Context, t: String): CommandResult? {
        if (!t.contains("timer")) return null
        val m = Regex("(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|ghanta|ghante|ghantey)").find(t) ?: return null
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = when {
            unit.startsWith("sec") -> n
            unit.startsWith("min") -> n * 60
            else -> n * 3600
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_MESSAGE, "NAYA")
        return if (start(ctx, i)) CommandResult("Starting a timer for $n ${unit.removeSuffix("s")}.")
        else CommandResult("I couldn't open the clock app.")
    }

    // ---- flashlight ----
    private var torchOn = false

    private fun tryTorch(ctx: Context, t: String): CommandResult? {
        if (!(t.contains("torch") || t.contains("flashlight") || t.contains("flash light"))) return null
        val off = Regex("\\b(off|band|bujha|bujhao)\\b").containsMatchIn(t)
        return runCatching {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return CommandResult("This phone has no flashlight.")
            torchOn = !off
            cm.setTorchMode(id, torchOn)
            CommandResult(if (torchOn) "Flashlight on." else "Flashlight off.")
        }.getOrElse { CommandResult("I couldn't control the flashlight.") }
    }

    // ---- battery / time / date ----
    private fun tryInfo(ctx: Context, t: String): CommandResult? {
        if (t.contains("battery") && t.length < 40) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            if (level < 0 || scale <= 0) return CommandResult("I couldn't read the battery level.")
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            return CommandResult("Battery is at ${level * 100 / scale} percent" + if (charging) " and charging." else ".")
        }
        if (Regex("(what('?s| is)? (the )?(current )?time|what time|time kya|kitne baje|current time|samay kya)").containsMatchIn(t)) {
            return CommandResult("It's " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("h:mm a")) + ".")
        }
        if (Regex("(what('?s| is)? (the )?(today'?s )?date|aaj ki date|aaj kya date|today'?s date|date kya)").containsMatchIn(t)) {
            return CommandResult("Today is " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")) + ".")
        }
        return null
    }

    // ---- call / navigate / search ----
    private fun tryCall(ctx: Context, t: String): CommandResult? {
        val m = Regex("^(?:call|dial|phone)\\s+(\\+?\\d[\\d\\s-]{4,})$").find(t) ?: return null
        val num = m.groupValues[1].replace(Regex("[\\s-]"), "")
        return if (start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))) CommandResult("Opening the dialer with $num. Tap call to confirm.")
        else CommandResult("I couldn't open the dialer.")
    }

    private fun tryNavigate(ctx: Context, t: String): CommandResult? {
        val m = Regex("^(?:navigate to|directions to|take me to|route to|map of)\\s+(.+)$").find(t) ?: return null
        val place = m.groupValues[1]
        return if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))) CommandResult("Opening maps for $place.")
        else CommandResult("I couldn't open a maps app.")
    }

    private fun trySearch(ctx: Context, t: String): CommandResult? {
        val q = Regex("^(?:search for|google)\\s+(.+)$").find(t)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s+search karo$").find(t)?.groupValues?.get(1)
            ?: return null
        return if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))) CommandResult("Searching for $q.")
        else CommandResult("I couldn't open the browser.")
    }

    // ---- open app / settings ----
    private fun tryOpen(ctx: Context, t: String): CommandResult? {
        val name = (Regex("^(?:please\\s+)?(?:open|launch)\\s+(.+)$").find(t)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s+(?:kholo|khol|chalao|chalu karo|open karo|launch karo)$").find(t)?.groupValues?.get(1)
            ?: return null).removeSuffix(" app").trim()

        val action = when {
            name.contains("wifi") || name.contains("wi-fi") -> Settings.ACTION_WIFI_SETTINGS
            name.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
            name.contains("location") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> null
        }
        if (action != null) {
            return if (start(ctx, Intent(action))) CommandResult("Opening $name.") else CommandResult("I couldn't open that setting.")
        }

        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: return CommandResult("I couldn't find an app named $name.")
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return CommandResult("I couldn't open $name.")
        return if (start(ctx, launch)) CommandResult("Opening ${match.loadLabel(pm)}.") else CommandResult("I couldn't open $name.")
    }
}

/** Tiny safe arithmetic evaluator: + - * / ( ) and decimals. */
object Calc {
    fun eval(src: String): Double? = runCatching { P(src.replace(" ", "")).parse() }.getOrNull()

    private class P(val s: String) {
        var i = 0

        fun parse(): Double {
            val v = expr()
            require(i == s.length)
            return v
        }

        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        fun factor(): Double {
            if (i < s.length && s[i] == '-') { i++; return -factor() }
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                require(i < s.length && s[i] == ')')
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            require(i > st)
            return s.substring(st, i).toDouble()
        }
    }
}
