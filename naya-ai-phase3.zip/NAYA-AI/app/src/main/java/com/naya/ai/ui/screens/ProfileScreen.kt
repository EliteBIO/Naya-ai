package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.avatar.AvatarState
import com.naya.ai.ui.MainViewModel

@Composable
fun ProfileScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    var name by rememberSaveable(s.displayName) { mutableStateOf(s.displayName) }

    ScreenColumn {
        ScreenHeader("Profile", "How NAYA greets you", onBack)
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            NayaAvatarView(AvatarState(), 160.dp)
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(40) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Your name") },
            singleLine = true,
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
        )
        NeonButton("Save name", Modifier.fillMaxWidth(), enabled = name.trim() != s.displayName) {
            vm.repo.update { it.copy(displayName = name.trim()) }
        }
        Text("Your name stays on this device.", color = NayaColors.TextDim, fontSize = 12.sp)
    }
}
