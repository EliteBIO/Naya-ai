package com.naya.ai.data

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String, val isSystem: Boolean = false)

data class Conversation(val id: Long, val title: String, val updated: Long, val messages: List<ChatMessage>)
