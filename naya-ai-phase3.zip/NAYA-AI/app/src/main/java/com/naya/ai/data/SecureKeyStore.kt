package com.naya.ai.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the API key encrypted with an AES key that lives in the Android Keystore
 * (the key material never leaves secure hardware/OS storage). Never hardcoded in the APK.
 */
class SecureKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("naya_secure", Context.MODE_PRIVATE)

    fun hasKey(): Boolean = prefs.contains(PREF)

    fun saveKey(key: String) {
        prefs.edit().putString(PREF, encrypt(key.trim())).apply()
    }

    /** Returns null if no key is saved or it can't be decrypted (re-save it in that case). */
    fun getKey(): String? {
        val stored = prefs.getString(PREF, null) ?: return null
        return decrypt(stored)
    }

    fun clear() {
        prefs.edit().remove(PREF).apply()
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String? = runCatching {
        val b = Base64.decode(stored, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, b, 0, 12))
        String(c.doFinal(b, 12, b.size - 12), Charsets.UTF_8)
    }.getOrNull()

    private companion object {
        const val ALIAS = "naya_api_key_v1"
        const val PREF = "gemini_key"
    }
}
