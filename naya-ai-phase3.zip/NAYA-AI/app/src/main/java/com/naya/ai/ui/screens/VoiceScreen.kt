package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.naya.ai.avatar.Expression
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.ui.ChatViewModel
import com.naya.ai.ui.MainViewModel
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import com.naya.ai.voice.VoicePhase
import com.naya.ai.voice.VoiceViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceScreen(vm: MainViewModel, voice: VoiceViewModel, chat: ChatViewModel, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val state by vm.avatar.state.collectAsState()
    val ui by voice.ui.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice.startListening() else voice.setNote("Microphone permission is needed to talk to NAYA.")
    }

    DisposableEffect(Unit) {
        voice.sendToAi = { text -> chat.send(text, spoken = true) }
        onDispose {
            voice.stopAll()
            voice.sendToAi = {}
        }
    }
    LaunchedEffect(Unit) { chat.events.collect { voice.onAiEvent(it) } }

    val micScale by animateFloatAsState(1f + ui.level * 0.3f, label = "mic")
    val phaseText = when (ui.phase) {
        VoicePhase.Idle -> "Tap the mic and talk"
        VoicePhase.Listening -> "Listening…"
        VoicePhase.Thinking -> "Thinking…"
        VoicePhase.Speaking -> "Speaking…"
    }
    val onMic = {
        when {
            ui.phase == VoicePhase.Listening -> voice.stopListening()
            ui.phase == VoicePhase.Thinking -> Unit
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> voice.startListening()
            else -> permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    ScreenColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NAYA Avatar", color = NayaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Talk to NAYA", color = NayaColors.TextDim, fontSize = 12.sp)
            }
            IconTextButton("✕", onExit)
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            NayaAvatarView(state, 280.dp)
        }
        Text(
            "${state.expression.label} · $phaseText",
            Modifier.fillMaxWidth(),
            color = state.expression.aura, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        )

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(96.dp)
                    .scale(micScale)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NayaColors.Blue, NayaColors.Purple)))
                    .clickable(onClick = onMic),
                contentAlignment = Alignment.Center,
            ) {
                Text(if (ui.phase == VoicePhase.Listening) "■" else "🎙", fontSize = 34.sp, color = Color.White)
            }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(selected = ui.live, onClick = { voice.toggleLive() }, label = { Text("Live chat") }, colors = nayaChipColors())
            FilterChip(selected = ui.muted, onClick = { voice.toggleMute() }, label = { Text("Mute NAYA") }, colors = nayaChipColors())
            FilterChip(selected = false, onClick = { voice.stopSpeaking() }, label = { Text("Stop speaking") }, colors = nayaChipColors())
        }

        if (ui.note.isNotEmpty()) Text(ui.note, color = NayaColors.Warn, fontSize = 13.sp)

        val youText = if (ui.partial.isNotEmpty()) ui.partial else ui.heard
        if (youText.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("You", color = NayaColors.TextDim, fontSize = 12.sp)
                Text(youText, color = NayaColors.TextPrimary)
            }
        }
        if (ui.reply.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("NAYA", color = NayaColors.TextDim, fontSize = 12.sp)
                Text(ui.reply, color = NayaColors.TextPrimary)
            }
        }

        SectionTitle("Try saying")
        Text(
            "“Open YouTube” · “Alarm 7:30 am” · “Timer 5 minutes” · “Torch on” · “Battery” · “Call 9876543210” · “Navigate to Delhi” · “Note: buy milk” · “Calculate 12 times 5”. Anything else goes to the AI.",
            color = NayaColors.TextDim, fontSize = 12.sp,
        )

        SectionTitle("Expression preview")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Expression.values().forEach { e ->
                FilterChip(
                    selected = state.expression == e,
                    onClick = { vm.avatar.setExpression(e) },
                    label = { Text(e.label) },
                    colors = nayaChipColors(),
                )
            }
        }
        Text(
            "Add your 12 face images (see FACES.md) and each expression shows your character's real face. Without them you see the original photo with a colored aura.",
            color = NayaColors.TextDim, fontSize = 12.sp,
        )

        FeatureList(
            listOf(
                Feature("Tap-to-talk and live chat", "Working", working = true),
                Feature("NAYA speaks (phone's text-to-speech voice)", "Working", working = true),
                Feature("Expressions follow listening / thinking / speaking", "Working", working = true),
                Feature("Face images per expression", "Add your images"),
                Feature("Exact lip-sync with speech sounds", "Later"),
            ),
        )
        Spacer(Modifier.height(8.dp))
    }
}
