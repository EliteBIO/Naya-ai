package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import androidx.compose.foundation.layout.*
import com.naya.ai.avatar.NayaAvatarView
import com.naya.ai.core.rememberIsOnline
import com.naya.ai.navigation.Routes
import com.naya.ai.ui.ChatViewModel
import com.naya.ai.ui.MainViewModel
import java.time.LocalTime

private fun greetingFor(hour: Int) = when {
    hour < 12 -> "Good morning"
    hour < 17 -> "Good afternoon"
    else -> "Good evening"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(vm: MainViewModel, chatVm: ChatViewModel, onNavigate: (String) -> Unit) {
    val chat by chatVm.ui.collectAsState()
    val hasKey = vm.secure.hasKey()
    val settings by vm.settings.collectAsState()
    val avatar by vm.avatar.state.collectAsState()
    val online = rememberIsOnline()
    val greeting = remember { greetingFor(LocalTime.now().hour) }
    val name = settings.displayName.trim()

    ScreenColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "NAYA AI",
                    style = TextStyle(
                        brush = Brush.horizontalGradient(listOf(NayaColors.Blue, NayaColors.Purple)),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 3.sp,
                    ),
                )
                Text("YOUR PERSONAL AI", color = NayaColors.TextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            IconTextButton("⚙") { onNavigate(Routes.Settings) }
        }

        Text(
            if (name.isEmpty()) greeting else "$greeting, $name",
            color = NayaColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
        )

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            NayaAvatarView(avatar, 250.dp)
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusBadge(if (online) "Internet: online" else "Internet: offline", if (online) NayaColors.Ok else NayaColors.Warn)
            if (hasKey) StatusBadge("AI brain: Gemini key saved", NayaColors.Ok) else StatusBadge("AI brain: add API key in Settings")
        }

        GlassCard(Modifier.fillMaxWidth(), onClick = { onNavigate(Routes.Chat) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ask NAYA anything…", Modifier.weight(1f), color = NayaColors.TextDim)
                Box(
                    Modifier.size(44.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NayaColors.Blue, NayaColors.Purple)))
                        .clickable { onNavigate(Routes.Voice) },
                    contentAlignment = Alignment.Center,
                ) { Text("🎙", fontSize = 20.sp) }
            }
        }

        SectionTitle("Quick tools")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile("🖼", "Photo Studio", "Image tools", Modifier.weight(1f)) { onNavigate(Routes.Photo) }
            QuickTile("🎬", "Video Studio", "Video tools", Modifier.weight(1f)) { onNavigate(Routes.Video) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile("🧰", "Tools", "Device info", Modifier.weight(1f)) { onNavigate(Routes.Tools) }
            QuickTile("💼", "Business", "Phase 9", Modifier.weight(1f)) { onNavigate(Routes.Business) }
        }

        SectionTitle("Recent conversations")
        if (chat.all.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("No saved conversations yet. Start one in Chat.", color = NayaColors.TextDim)
            }
        } else {
            chat.all.take(3).forEach { c ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { chatVm.open(c.id); onNavigate(Routes.Chat) }) {
                    Text(c.title.ifBlank { "Untitled" }, color = NayaColors.TextPrimary, maxLines = 1)
                    Text("${c.messages.size} messages", color = NayaColors.TextDim, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun QuickTile(glyph: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier, onClick) {
        Text(glyph, fontSize = 26.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, color = NayaColors.TextPrimary, fontWeight = FontWeight.SemiBold)
        Text(sub, color = NayaColors.TextDim, fontSize = 12.sp)
    }
}
