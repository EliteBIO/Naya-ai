package com.naya.ai.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.naya.ai.ui.components.*
import com.naya.ai.ui.theme.NayaColors
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class VideoInfo(val durationMs: Long, val width: Int, val height: Int, val frame: ImageBitmap?)

private fun loadVideoInfo(ctx: Context, uri: Uri): VideoInfo? = runCatching {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val frame = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.asImageBitmap()
        VideoInfo(dur, w, h, frame)
    } finally {
        r.release()
    }
}.getOrNull()

private fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen() {
    val ctx = LocalContext.current
    var prompt by rememberSaveable { mutableStateOf("") }
    var ratio by rememberSaveable { mutableStateOf("16:9") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri = it }
    LaunchedEffect(uri) {
        info = uri?.let { u -> withContext(Dispatchers.IO) { loadVideoInfo(ctx, u) } }
    }

    ScreenColumn {
        ScreenHeader("Video Studio", "Video generation and editing")
        StatusBadge("Generation: awaiting video provider + credits (Phase 6)")

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Describe the video (draft, not sent anywhere yet)") },
            colors = nayaFieldColors(),
            shape = RoundedCornerShape(16.dp),
            minLines = 3,
        )

        SectionTitle("Aspect ratio")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("16:9", "9:16", "1:1", "4:3").forEach { r ->
                FilterChip(selected = ratio == r, onClick = { ratio = r }, label = { Text(r) }, colors = nayaChipColors())
            }
        }

        SectionTitle("Source video")
        NeonButton("Pick video from gallery") {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }
        val v = info
        if (v != null) {
            GlassCard(Modifier.fillMaxWidth()) {
                val f = v.frame
                if (f != null) {
                    Image(
                        bitmap = f,
                        contentDescription = "First frame",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(12.dp)),
                    )
                    Spacer(Modifier.height(8.dp))
                }
                Text(
                    "Duration ${formatDuration(v.durationMs)}  ·  ${v.width}×${v.height}",
                    color = NayaColors.TextPrimary, fontSize = 13.sp,
                )
                Text("Showing the first frame. Playback and trimming arrive in Phase 6.", color = NayaColors.TextDim, fontSize = 12.sp)
            }
        } else if (uri != null) {
            Text("Couldn't read that video. Try another file.", color = NayaColors.Warn, fontSize = 13.sp)
        }

        NeonButton("Generate video", Modifier.fillMaxWidth(), enabled = false) {}
        FeatureList(
            listOf(
                Feature("Pick video, read info, preview first frame", "Working", working = true),
                Feature("Text-to-video and image-to-video", "Phase 6"),
                Feature("Playback and trimming", "Phase 6"),
                Feature("Save frame as image", "Phase 6"),
                Feature("AI video summary", "Phase 6"),
                Feature("Export and generation history", "Phase 6"),
            ),
        )
        Spacer(Modifier.height(8.dp))
    }
}
