package com.naya.ai.tools

import android.content.Context
import org.json.JSONArray

/** Local notes (offline). Newest first. */
class NotesStore(context: Context) {
    private val prefs = context.getSharedPreferences("naya_notes", Context.MODE_PRIVATE)

    fun list(): List<String> = runCatching {
        val a = JSONArray(prefs.getString("n", "[]"))
        List(a.length()) { a.getString(it) }
    }.getOrDefault(emptyList())

    fun add(text: String) = save(listOf(text) + list())

    fun delete(index: Int) = save(list().filterIndexed { i, _ -> i != index })

    private fun save(l: List<String>) {
        prefs.edit().putString("n", JSONArray(l).toString()).apply()
    }
}
