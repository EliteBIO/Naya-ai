# NAYA face images (same character, many expressions)

Make each image from your original character photo (Gemini / ChatGPT image editing):
"Keep this exact character, same hair, headset, outfit and background. Only change the expression to: <EXPRESSION>."
Use square images, about 1024x1024, PNG or JPG, under ~500 KB each.

Name the files EXACTLY like this (lowercase, no spaces) and upload them to the ROOT of your GitHub repo:

expr_neutral.png      expr_happy.png       expr_smiling.png     expr_laughing.png
expr_thinking.png     expr_confused.png    expr_surprised.png   expr_excited.png
expr_concerned.png    expr_explaining.png  expr_listening.png   expr_speaking.png

Optional (makes her look alive):
naya_open.png   = same character, mouth open as if talking (used while speaking)
naya_blink.png  = neutral face with eyes closed (random blinks)

Use ONE file type per name (do not upload both expr_happy.png and expr_happy.jpg).
Any image you skip falls back to your original photo.
